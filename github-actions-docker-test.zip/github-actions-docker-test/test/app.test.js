const assert = require("node:assert/strict");
const { getStatus } = require("../app");

const result = getStatus();

assert.equal(result.status, "ok");
assert.match(result.runtime, /^v\d+\./);
assert.equal(typeof result.message, "string");
assert.ok(result.message.length > 0);

console.log("Все тесты пройдены.");
